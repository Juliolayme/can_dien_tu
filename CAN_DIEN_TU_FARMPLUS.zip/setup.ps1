# Setup script - Phan mem Can Dien Tu FarmPlus
# Chay voi quyen Administrator de cai day du

$ErrorActionPreference = "SilentlyContinue"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$appDir = Join-Path $scriptDir "App"

Write-Host ""
Write-Host "=== CAI DAT PHAN MEM CAN DIEN TU FARMPLUS ===" -ForegroundColor Cyan
Write-Host ""

# -------------------------------------------------------
# 1. Unblock tất cả file (bỏ khóa Windows SmartScreen)
# -------------------------------------------------------
Write-Host "[1/5] Go khoa Windows SmartScreen..." -ForegroundColor Yellow
Get-ChildItem -Path $scriptDir -Recurse -File | ForEach-Object {
    try { Unblock-File -Path $_.FullName -ErrorAction SilentlyContinue } catch {}
}
Write-Host "      Xong." -ForegroundColor Green

# -------------------------------------------------------
# 2. Cài font chữ số digital
# -------------------------------------------------------
Write-Host "[2/5] Cai font chu so digital..." -ForegroundColor Yellow
$fontSrc = Join-Path $appDir "fonts\digital-7__mono_.ttf"
$userFontDir = "$env:LOCALAPPDATA\Microsoft\Windows\Fonts"
New-Item -ItemType Directory -Path $userFontDir -Force | Out-Null

if (Test-Path $fontSrc) {
    $fontDst = Join-Path $userFontDir "digital-7__mono_.ttf"
    Copy-Item -Path $fontSrc -Destination $fontDst -Force
    # Đăng ký font trong registry (user-level)
    $regPath = "HKCU:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Fonts"
    Set-ItemProperty -Path $regPath -Name "Digital-7 Mono (TrueType)" -Value $fontDst -Force
    Write-Host "      Font da cai vao: $fontDst" -ForegroundColor Green
} else {
    Write-Host "      CANH BAO: Khong tim thay file font!" -ForegroundColor Red
}

# -------------------------------------------------------
# 3. Ghi registry key bypass (đăng ký phần mềm)
# -------------------------------------------------------
Write-Host "[3/5] Dang ky phan mem..." -ForegroundColor Yellow
try {
    $null = New-Item -Path "HKCU:\cprVietDucAnhChi" -Force
    Set-ItemProperty -Path "HKCU:\cprVietDucAnhChi" -Name "(Default)" -Value "vietduc123" -Force
    $null = New-Item -Path "HKCU:\cprDTH" -Force
    Set-ItemProperty -Path "HKCU:\cprDTH" -Name "(Default)" -Value "sondt" -Force
    Write-Host "      Dang ky thanh cong." -ForegroundColor Green
} catch {
    Write-Host "      Loi dang ky: $_" -ForegroundColor Red
}

# -------------------------------------------------------
# 4. Tạo shortcut Desktop
# -------------------------------------------------------
Write-Host "[4/5] Tao shortcut tren Desktop..." -ForegroundColor Yellow
try {
    $exePath = Join-Path $appDir "Chuongtrinhcan.exe"
    $icoPath = Join-Path $appDir "SLogo.ico"
    $shortcutPath = "$env:USERPROFILE\Desktop\Can Dien Tu.lnk"

    $wsh = New-Object -ComObject WScript.Shell
    $shortcut = $wsh.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $exePath
    $shortcut.WorkingDirectory = $appDir
    $shortcut.IconLocation = $icoPath
    $shortcut.Description = "Phan mem Can Dien Tu FarmPlus"
    $shortcut.Save()
    Write-Host "      Shortcut: $shortcutPath" -ForegroundColor Green
} catch {
    Write-Host "      Loi tao shortcut: $_" -ForegroundColor Red
}

# -------------------------------------------------------
# 5. Cap nhat thong tin cong ty trong database
# -------------------------------------------------------
Write-Host "[5/6] Cap nhat thong tin cong ty trong database..." -ForegroundColor Yellow
try {
    $mdbPath = Join-Path $appDir "sys\data.mdb"
    $pass = '!@#^%$Nguyen1Van2A3'
    $conn = New-Object System.Data.OleDb.OleDbConnection
    $conn.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=$mdbPath;Jet OLEDB:Database Password=$pass;"
    $conn.Open()

    $tenCty    = "C" + [char]0x00D4 + "NG TY TNHH FARMPLUS"
    $diachi    = "C" + [char]0x00D4 + "NG TY TNHH FARMPLUS (MST: 1501164307)"
    $dienthoai = [char]0x0110 + "C: S" + [char]0x1ED1 + " 44E " `
        + [char]0x0111 + [char]0x01B0 + [char]0x1EDD + "ng Tr" + [char]0x1EA7 + "n " `
        + [char]0x0110 + [char]0x1EA1 + "i Ngh" + [char]0x0129 + "a, Ph" `
        + [char]0x01B0 + [char]0x1EDD + "ng Ph" + [char]0x01B0 + [char]0x1EDB + "c H" + [char]0x1EAD + "u, " `
        + "T" + [char]0x1EC9 + "nh V" + [char]0x0129 + "nh Long, Vi" + [char]0x1EC7 + "t Nam " `
        + "S" + [char]0x0110 + "T: 0989799429"

    $cmd = $conn.CreateCommand()
    $cmd.CommandText = "UPDATE giaotiep SET tencty=?, diachi=?, dienthoai=?"
    $null = $cmd.Parameters.Add("?", [System.Data.OleDb.OleDbType]::VarWChar); $cmd.Parameters[0].Value = $tenCty
    $null = $cmd.Parameters.Add("?", [System.Data.OleDb.OleDbType]::VarWChar); $cmd.Parameters[1].Value = $diachi
    $null = $cmd.Parameters.Add("?", [System.Data.OleDb.OleDbType]::VarWChar); $cmd.Parameters[2].Value = $dienthoai
    $null = $cmd.ExecuteNonQuery()
    $conn.Close()
    Write-Host "      Cap nhat thanh cong." -ForegroundColor Green
} catch {
    Write-Host "      Loi cap nhat database: $_" -ForegroundColor Red
}

# -------------------------------------------------------
# 6. Kiểm tra Microsoft Access Database Engine
# -------------------------------------------------------
Write-Host "[6/6] Kiem tra Access Database Engine..." -ForegroundColor Yellow
$aceKey = "HKLM:\SOFTWARE\Microsoft\Office\14.0\Access Connectivity Engine\Engines"
$aceKey2 = "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Office\14.0\Access Connectivity Engine\Engines"
$aceInstalled = (Test-Path $aceKey) -or (Test-Path $aceKey2)

# Kiểm tra qua ODBC drivers
$drivers = (Get-OdbcDriver -ErrorAction SilentlyContinue).Name -join ","
$aceInstalled = $aceInstalled -or ($drivers -like "*Microsoft Access Driver*")

if ($aceInstalled) {
    Write-Host "      Access Database Engine: Co san." -ForegroundColor Green
} else {
    Write-Host "      CANH BAO: Chua co Access Database Engine!" -ForegroundColor Red
    Write-Host "      --> Can cai: Microsoft Access Database Engine 2010 (32-bit)" -ForegroundColor Yellow
    Write-Host "      --> Tai tai: https://www.microsoft.com/en-us/download/details.aspx?id=13255" -ForegroundColor Yellow
}

# -------------------------------------------------------
# Hoàn thành
# -------------------------------------------------------
Write-Host ""
Write-Host "=== CAI DAT HOAN TAT ===" -ForegroundColor Cyan
Write-Host ""
Write-Host "Shortcut 'Can Dien Tu' da duoc tao tren Desktop." -ForegroundColor White
Write-Host "Bam doi lan vao shortcut de mo phan mem." -ForegroundColor White
Write-Host ""

# Hỏi có muốn mở app ngay không
$answer = Read-Host "Mo phan mem ngay bay gio? (y/n)"
if ($answer -eq "y" -or $answer -eq "Y") {
    $exePath = Join-Path $appDir "Chuongtrinhcan.exe"
    Start-Process -FilePath $exePath -WorkingDirectory $appDir
}
