@echo off
chcp 65001 >nul
echo ========================================
echo   CAI DAT PHAN MEM CAN DIEN TU FARMPLUS
echo ========================================
echo.

:: Chạy PowerShell script cài đặt
powershell.exe -ExecutionPolicy Bypass -File "%~dp0setup.ps1"

pause
