@echo off
chcp 65001 >nul
:: Chay GUI bang PowerShell 32-bit che do STA (bat buoc cho WinForms + JET OLEDB)
start "" C:\Windows\SysWOW64\WindowsPowerShell\v1.0\powershell.exe ^
    -STA -ExecutionPolicy Bypass ^
    -File "%~dp0sua_ngay_phieu_gui.ps1"
