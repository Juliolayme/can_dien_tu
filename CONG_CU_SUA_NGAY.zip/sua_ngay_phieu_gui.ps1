# GUI Sua ngay gio phieu can - Can Dien Tu FarmPlus
# Chay bang PowerShell 32-bit (STA) de dung WinForms + JET OLEDB

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- Tim thu muc app ---
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
if (Test-Path (Join-Path $scriptDir "Chuongtrinhcan.exe")) {
    $appDir = $scriptDir
} elseif (Test-Path (Join-Path $scriptDir "App\Chuongtrinhcan.exe")) {
    $appDir = Join-Path $scriptDir "App"
} else {
    [System.Windows.Forms.MessageBox]::Show("Khong tim thay Chuongtrinhcan.exe.`nHay dat file nay cung thu muc voi phan mem.", "Loi", "OK", "Error") | Out-Null
    exit 1
}
$script:mdbPath = Join-Path $appDir "sys\data.mdb"
$script:pass = '!@#^%$Nguyen1Van2A3'

function New-Conn {
    $c = New-Object System.Data.OleDb.OleDbConnection
    $c.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=$($script:mdbPath);Jet OLEDB:Database Password=$($script:pass);"
    return $c
}

# =======================================================
# FORM
# =======================================================
$form = New-Object System.Windows.Forms.Form
$form.Text = "Sua ngay gio phieu can - FarmPlus"
$form.Size = New-Object System.Drawing.Size(720, 540)
$form.StartPosition = "CenterScreen"
$form.Font = New-Object System.Drawing.Font("Segoe UI", 10)

# --- Dong loc ngay ---
$lblLoc = New-Object System.Windows.Forms.Label
$lblLoc.Text = "Ngay can:"
$lblLoc.Location = New-Object System.Drawing.Point(15, 18)
$lblLoc.AutoSize = $true
$form.Controls.Add($lblLoc)

$dtpLoc = New-Object System.Windows.Forms.DateTimePicker
$dtpLoc.Format = "Custom"
$dtpLoc.CustomFormat = "dd/MM/yyyy"
$dtpLoc.Location = New-Object System.Drawing.Point(90, 15)
$dtpLoc.Size = New-Object System.Drawing.Size(130, 25)
$form.Controls.Add($dtpLoc)

$btnLoc = New-Object System.Windows.Forms.Button
$btnLoc.Text = "Loc phieu"
$btnLoc.Location = New-Object System.Drawing.Point(235, 14)
$btnLoc.Size = New-Object System.Drawing.Size(100, 28)
$form.Controls.Add($btnLoc)

# --- Bang danh sach phieu ---
$grid = New-Object System.Windows.Forms.DataGridView
$grid.Location = New-Object System.Drawing.Point(15, 55)
$grid.Size = New-Object System.Drawing.Size(675, 300)
$grid.ReadOnly = $true
$grid.AllowUserToAddRows = $false
$grid.AllowUserToDeleteRows = $false
$grid.SelectionMode = "FullRowSelect"
$grid.MultiSelect = $false
$grid.AutoSizeColumnsMode = "Fill"
$grid.RowHeadersVisible = $false
$grid.BackgroundColor = [System.Drawing.Color]::White
$form.Controls.Add($grid)

# --- Khu vuc sua ngay ---
$lblChon = New-Object System.Windows.Forms.Label
$lblChon.Text = "Phieu dang chon: (chua chon)"
$lblChon.Location = New-Object System.Drawing.Point(15, 370)
$lblChon.AutoSize = $true
$lblChon.Font = New-Object System.Drawing.Font("Segoe UI", 10, [System.Drawing.FontStyle]::Bold)
$form.Controls.Add($lblChon)

$lblMoi = New-Object System.Windows.Forms.Label
$lblMoi.Text = "Ngay gio moi:"
$lblMoi.Location = New-Object System.Drawing.Point(15, 410)
$lblMoi.AutoSize = $true
$form.Controls.Add($lblMoi)

$dtpMoi = New-Object System.Windows.Forms.DateTimePicker
$dtpMoi.Format = "Custom"
$dtpMoi.CustomFormat = "dd/MM/yyyy HH:mm:ss"
$dtpMoi.ShowUpDown = $true
$dtpMoi.Location = New-Object System.Drawing.Point(120, 407)
$dtpMoi.Size = New-Object System.Drawing.Size(200, 25)
$dtpMoi.Enabled = $false
$form.Controls.Add($dtpMoi)

$btnLuu = New-Object System.Windows.Forms.Button
$btnLuu.Text = "Luu ngay moi"
$btnLuu.Location = New-Object System.Drawing.Point(340, 405)
$btnLuu.Size = New-Object System.Drawing.Size(140, 30)
$btnLuu.BackColor = [System.Drawing.Color]::FromArgb(46, 160, 67)
$btnLuu.ForeColor = [System.Drawing.Color]::White
$btnLuu.Enabled = $false
$form.Controls.Add($btnLuu)

$lblTrangThai = New-Object System.Windows.Forms.Label
$lblTrangThai.Text = ""
$lblTrangThai.Location = New-Object System.Drawing.Point(15, 455)
$lblTrangThai.Size = New-Object System.Drawing.Size(675, 40)
$lblTrangThai.ForeColor = [System.Drawing.Color]::DarkBlue
$form.Controls.Add($lblTrangThai)

# =======================================================
# LOGIC
# =======================================================
$script:sttChon = $null

# --- Ham loc phieu theo ngay ---
$loadPhieu = {
    $lblChon.Text = "Phieu dang chon: (chua chon)"
    $dtpMoi.Enabled = $false
    $btnLuu.Enabled = $false
    $script:sttChon = $null
    $lblTrangThai.Text = ""

    $ngay = $dtpLoc.Value.Date
    try {
        $conn = New-Conn
        $conn.Open()
        $cmd = $conn.CreateCommand()
        $cmd.CommandText = "SELECT p.Stt, p.Sophieu, p.Soxe, k.tenkh AS Khachhang, p.Ngaycan " +
                           "FROM Phieucan p LEFT JOIN Khachhang k ON p.KH_ID = k.ID " +
                           "WHERE p.Ngaycan >= ? AND p.Ngaycan <= ? ORDER BY p.Ngaycan"
        $null = $cmd.Parameters.Add("?", [System.Data.OleDb.OleDbType]::Date); $cmd.Parameters[0].Value = $ngay
        $null = $cmd.Parameters.Add("?", [System.Data.OleDb.OleDbType]::Date); $cmd.Parameters[1].Value = $ngay.AddDays(1).AddSeconds(-1)
        $da = New-Object System.Data.OleDb.OleDbDataAdapter($cmd)
        $dt = New-Object System.Data.DataTable
        $da.Fill($dt) | Out-Null
        $conn.Close()

        $grid.DataSource = $dt
        if ($grid.Columns.Contains("Stt"))     { $grid.Columns["Stt"].Visible = $false }
        if ($grid.Columns.Contains("Sophieu")) { $grid.Columns["Sophieu"].HeaderText = "So phieu" }
        if ($grid.Columns.Contains("Soxe"))    { $grid.Columns["Soxe"].HeaderText = "So xe" }
        if ($grid.Columns.Contains("Khachhang")) { $grid.Columns["Khachhang"].HeaderText = "Khach hang" }
        if ($grid.Columns.Contains("Ngaycan")) { $grid.Columns["Ngaycan"].HeaderText = "Ngay gio can" }
        $grid.ClearSelection()

        $lblTrangThai.Text = "Tim thay $($dt.Rows.Count) phieu ngay $($ngay.ToString('dd/MM/yyyy'))."
    } catch {
        $lblTrangThai.ForeColor = [System.Drawing.Color]::Red
        $lblTrangThai.Text = "Loi doc du lieu: $_"
    }
}

$btnLoc.Add_Click($loadPhieu)

# --- Khi chon 1 dong ---
$grid.Add_SelectionChanged({
    if ($grid.SelectedRows.Count -gt 0) {
        $row = $grid.SelectedRows[0]
        if ($null -ne $row.Cells["Stt"].Value) {
            $script:sttChon = [int]$row.Cells["Stt"].Value
            $sophieu = $row.Cells["Sophieu"].Value
            $soxe = $row.Cells["Soxe"].Value
            $ngayHT = [datetime]$row.Cells["Ngaycan"].Value
            $lblChon.Text = "Phieu dang chon: So phieu $sophieu | So xe: $soxe"
            $dtpMoi.Value = $ngayHT
            $dtpMoi.Enabled = $true
            $btnLuu.Enabled = $true
        }
    }
})

# --- Luu ngay moi ---
$btnLuu.Add_Click({
    if ($null -eq $script:sttChon) { return }
    $ngayMoi = $dtpMoi.Value

    $xn = [System.Windows.Forms.MessageBox]::Show(
        "Cap nhat ngay gio phieu thanh:`n$($ngayMoi.ToString('dd/MM/yyyy HH:mm:ss'))?",
        "Xac nhan", "YesNo", "Question")
    if ($xn -ne "Yes") { return }

    try {
        $conn = New-Conn
        $conn.Open()

        # Update Phieucan
        $c1 = $conn.CreateCommand()
        $c1.CommandText = "UPDATE Phieucan SET Ngaycan=? WHERE Stt=?"
        $null = $c1.Parameters.Add("?", [System.Data.OleDb.OleDbType]::Date); $c1.Parameters[0].Value = $ngayMoi
        $null = $c1.Parameters.Add("?", [System.Data.OleDb.OleDbType]::Integer); $c1.Parameters[1].Value = $script:sttChon
        $r1 = $c1.ExecuteNonQuery()

        # Doc chi tiet - giu gio rieng tung dong, chi doi ngay
        $c2 = $conn.CreateCommand()
        $c2.CommandText = "SELECT ID, Ngaycanct FROM ChitietPhieucan WHERE Phieu_ID=?"
        $null = $c2.Parameters.Add("?", [System.Data.OleDb.OleDbType]::Integer); $c2.Parameters[0].Value = $script:sttChon
        $rd = $c2.ExecuteReader()
        $cts = @()
        while ($rd.Read()) { $cts += @{ ID = $rd["ID"]; Ngay = [datetime]$rd["Ngaycanct"] } }
        $rd.Close()

        $r2 = 0
        foreach ($ct in $cts) {
            $ngayCT = [datetime]::new($ngayMoi.Year, $ngayMoi.Month, $ngayMoi.Day, $ct.Ngay.Hour, $ct.Ngay.Minute, $ct.Ngay.Second)
            $c3 = $conn.CreateCommand()
            $c3.CommandText = "UPDATE ChitietPhieucan SET Ngaycanct=? WHERE ID=?"
            $null = $c3.Parameters.Add("?", [System.Data.OleDb.OleDbType]::Date); $c3.Parameters[0].Value = $ngayCT
            $null = $c3.Parameters.Add("?", [System.Data.OleDb.OleDbType]::Integer); $c3.Parameters[1].Value = $ct.ID
            $r2 += $c3.ExecuteNonQuery()
        }
        $conn.Close()

        $lblTrangThai.ForeColor = [System.Drawing.Color]::Green
        $lblTrangThai.Text = "Da luu! Phieucan: $r1 dong, ChitietPhieucan: $r2 dong. Mo lai app va in phieu de kiem tra."

        # Load lai danh sach
        & $loadPhieu
    } catch {
        $lblTrangThai.ForeColor = [System.Drawing.Color]::Red
        $lblTrangThai.Text = "Loi cap nhat: $_"
    }
})

# Load ngay hom nay khi mo form
$form.Add_Shown({ & $loadPhieu })
[System.Windows.Forms.Application]::EnableVisualStyles()
$form.ShowDialog() | Out-Null
